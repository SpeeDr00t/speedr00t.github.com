FFDshow SEH Exception leading to NULL pointer on Read
Author: Matthew Bergin
Website: http://berginpentesting.com/
Email: matt@berginpentesting.com
Date: 09/02/10
Filename: C:\Program Files\K-Lite Codec Pack\FFDshow\ffdshow.ax
Version: v1.1.3530.0
License: GNU General Public License

Description


Crash Instructions
kernel32.7c812afb 5E 			POP ESI ffdshow.02659580 <- Exception E06d7363
kernel32.7c812afc C9 			LEAVE
kernel32.7c812afd C2 1000		RETN 10
ffdshow.0261a804  C9			LEAVE
ffdshow.0261a805  C2 0800		RETN 8
ffdshow.023cc407  8b45 08		MOV EAX, DWORD PTR SS:[EBP+8]
ffdshow.023cc4da  50			PUSH EAX			ffdshow.026fbe9c
ffdshow.023cc4db  E8 70FEFFFF		CALL ffdshow.023cc350
ffdshow.023cc350  55			PUSH EBP
ffdshow.023cc351  8BEC			MOV EBP,ESP
ffdshow.023cc353  6A FF			PUSH -1
ffdshow.023cc355  68 C1826402		PUSH ffdshow.026482c1
ffdshow.023cc35a  61:A1 00000000	MOV EAX, DWORD PTR FS:[0]
ffdshow.023cc360  50			PUSH EAX
ffdshow.023cc361  64:8925 00000000      MOV DWORD PTR FS:[0], ESP
ffdshow.023CC368  83EC 1C          	SUB ESP,1C
ffdshow.023CC36B  53               	PUSH EBX
ffdshow.023CC36C  33C0             	XOR EAX,EAX
ffdshow.023CC36E  56               	PUSH ESI
ffdshow.023CC36F  8945 EC          	MOV DWORD PTR SS:[EBP-14],EAX
ffdshow.023CC372  57               	PUSH EDI
ffdshow.023CC373  8B7D 08          	MOV EDI,DWORD PTR SS:[EBP+8]
ffdshow.023CC376  8907             	MOV DWORD PTR DS:[EDI],EAX
ffdshow.023CC378  8965 F0          	MOV DWORD PTR SS:[EBP-10],ESP
ffdshow.023CC37B  8947 04          	MOV DWORD PTR DS:[EDI+4],EAX
ffdshow.023CC37E  8D45 E4          	LEA EAX,DWORD PTR SS:[EBP-1C]
ffdshow.023CC381  BB 01000000      	MOV EBX,1
ffdshow.023CC386  50               	PUSH EAX
ffdshow.023CC387  895D EC          	MOV DWORD PTR SS:[EBP-14],EBX
ffdshow.023CC38A  895D FC          	MOV DWORD PTR SS:[EBP-4],EBX
ffdshow.023CC38D  E8 EEFDFFFF      	CALL ffdshow.023CC180
...
...
ffdshow.023CC19E  33C0       	      	XOR EAX,EAX
ffdshow.023CC1A0  8965 F0       	MOV DWORD PTR SS:[EBP-10],ESP
ffdshow.023CC1A3  50              	PUSH EAX
ffdshow.023CC1A4  50               	PUSH EAX
ffdshow.023CC1A5  8945 EC          	MOV DWORD PTR SS:[EBP-14],EAX
ffdshow.023CC1A8  8945 FC          	MOV DWORD PTR SS:[EBP-4],EAX
ffdshow.023CC1AB  E8 0CE62400      	CALL ffdshow.0261A7BC
ffdshow.023CC1B0  8B4D E8          	MOV ECX,DWORD PTR SS:[EBP-18]
ffdshow.023CC1B3  8B01             	MOV EAX,DWORD PTR DS:[ECX] <- Access Violation when reading 00000000 NULL pointer
ffdshow.023CC1B5  8B10             	MOV EDX,DWORD PTR DS:[EAX]
ffdshow.023CC1B7  FFD2             	CALL EDX


Crash Registers on Exception
EAX 01d0db3c
ECX 00000000
EDX 01d0dbe0
EBX 00000000
ESP 01d0db38
EBP 01d0db8c
ESI 01d0dbc4
EDI 00000000
EIP 7c812afb kernel32.7c812afb


Crash Registers on Violation
EAX 01d0da8c
ECX 00000000
EDX 01d0dbe0
EBX 00000001
ESP 01d0db24
EBP 01d0db88
ESI 02659580 ffdshow.02659580
EDI 026fbe9c ffdshow.026fbe9c
EIP 023cc1b3 ffdshow.023cc1b3


Stack
01D0DBD0  |026FBE9C  ffdshow.026FBE9C
01D0DBD4  |00000000
01D0DBD8  |02659580  ffdshow.02659580
01D0DBDC  |00000000
01D0DBE0  |0265B7E4  ffdshow.0265B7E4
01D0DBE4  |00000000
01D0DBE8  |0265BC88  ASCII "boost::current_exception()"
01D0DBEC  |0265BC58  ASCII "src\boost/exception/detail/exception_ptr.hpp"
01D0DBF0  |00000050
01D0DBF4  |0265B7D8  ffdshow.0265B7D8
01D0DBF8  |0265B544  ASCII "bad allocation"
01D0DBFC  |00000000
01D0DC00  |0265B8C4  ffdshow.0265B8C4
01D0DC04  |00000000
01D0DC08  |01D0DBD4
01D0DC0C  |01D0DC50  Pointer to next SEH record
01D0DC10  |026482D0  SE handler
01D0DC14  |00000000
01D0DC18  ]01D0DC6C
01D0DC1C  |023CC5A4  RETURN to ffdshow.023CC5A4 from ffdshow.023CC490
01D0DC20  |026FBE9C  ffdshow.026FBE9C
01D0DC24  |01D0DC30
01D0DC28  |023B0000  ffdshow.023B0000
01D0DC2C  |00000000
01D0DC30  |0265B7C4  ffdshow.0265B7C4
01D0DC34  |00000000
01D0DC38  |0265BC88  ASCII "boost::current_exception()"
01D0DC3C  |0265BC58  ASCII "src\boost/exception/detail/exception_ptr.hpp"
01D0DC40  |00000050
01D0DC44  |0265B7CC  ffdshow.0265B7CC
01D0DC48  |0265B544  ASCII "bad allocation"
01D0DC4C  |00000000
01D0DC50  |01D0DCBC  Pointer to next SEH record
01D0DC54  |026482FE  SE handler


Reproduction
Use attached PoC

